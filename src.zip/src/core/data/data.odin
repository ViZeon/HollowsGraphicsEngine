package data

import "core:time"
import "core:strings"

import math "core:math/linalg/glsl"

APP_CLOSED := false

APP_TIME: i64 = 0.0
FRAME_TIME: i64 = 0.0

FPS := 0
DEBUG_TIME := 2.0
DEBUG_LAST_TIME := 0.0

// Window constants
WINDOW_WIDTH_PERCENT :: 0.7
WINDOW_HEIGHT_PERCENT :: 0.8
WINDOW_TITLE :: "Compute Engine"

CAM_POS: math.vec3 //= {-581.8, -224.2, -0.7} // Model is 0 to 3.8 tall, so center Y is 1.9
CAM_SPEED :: 0.1 // Units per frame

FRAME_DATA: FrameData = {
	frame_count   = 0,
	previous_time = 0,
	FRAME_TITLE   = WINDOW_TITLE,
}


// Spatial grid
CELLS: [dynamic]Grid_Key
//In meters
// WARNING: KEEP AROUND 100 METERS TO BE SAFE
DEPRACATED_WORLD_SIZE :i32= 100

CELL_SIZE :i32= 1
WORLD_SIZE :i32= 1000
Cell:: struct {
	Children_exist :bool,
	Children : []int,
}

Grid_Key :: struct {
	keys:    [dynamic]i32,
	closest: [dynamic]i32,
	Average: Vertex
}


// Model constants

VERTICIES_RAW: []Vertex
MODEL_INITIALIZED: bool = false
MODEL_DATA: Model_Data



CACHE_PATH :: "cache/verts.bin"

//Demo models, uncomment the target one
//
//MODEL_PATH :: "assets/kenny_blaster/blaster-e.glb"
//MODEL_PATH :: "assets/1mSphere.glb"
MODEL_PATH :: "assets/ABeautifulGame.glb"
LOG_PATH :: "./debug/"

SCALE_FACTOR :: 10.0
FOV :: 60
CULLING_RANGE :: 300.0

// Shader constants
COMPUTE_SHADER_PATH :: "test_compute.glsl"

LOG_BOARD : strings.Builder

// Create arrays
xs: []Sorted_Axis
ys: []Sorted_Axis
zs: []Sorted_Axis


WORLD_BITFIELD : Mipmap_Bitfield

// Each uint32 can hold:
// - 8 bits for one parent's children (bits 0-7)
// - Plus 24 more bits for other data or additional cells

// OR simpler: just store sequentially and calculate offsets
Mipmap_Bitfield :: struct {
    bits: [dynamic]u32,
    transbits: [dynamic]u32,  // Start index for each mip level
}

DataPointType :: enum {
	Cell
}

DataPoint :: struct {
	Type : DataPointType,
	ID : int
}

// Each entry holds the value and the original index
Sorted_Axis :: struct {
	value: f32,
	index: int,
}

// Vertex structure
//renamed to DataPoint, maybe I should keep as vert and use another variable
Vertex :: struct {
	pos:    math.vec3,
	normal: math.vec3,
	fov:    f32,
}

// Model data
Model_Data :: struct {
	VERTICES:   []Vertex,
	BOUNDS:     Bounds,
	MAX_RADIUS: f32,
}


// Render state
Render_State :: struct {
	ssbo:            u32,
	output_texture:  u32,
	compute_program: u32,
	display_program: u32,
	vao:             u32,
	window_width:    i32,
	window_height:   i32,
}

FrameData :: struct {
	frame_count:   int,
	previous_time: f64,
	FRAME_TITLE:   cstring,
}

Bounds :: struct {
	x: Range,
	y: Range,
	z: Range,
}

Range :: struct {
	min: f32,
	max: f32,
}
